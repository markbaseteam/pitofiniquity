### Initiative
- First round rolled normally
- Subsequent rounds are auto re-rolled by the DM.
	*I thought it would be cool to roll a new initiative order for each round of combat. That way, higher DEX character would generally be near the top more often and lower DEX characters would tend toward the bottom. I have a tool that's able to quickly roll initiative for PCs and NPCs and takes into account all the ability modifiers, bonuses, and effects.* 

### Death
- When a PC reaches 0 HP they are dead.


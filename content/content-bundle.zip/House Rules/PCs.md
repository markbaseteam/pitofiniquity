### Character Creation

###### Attributes during character creation
- Each attribute is rolled once, in order, with 3d6. 
- One attribute may be replaced by a 14.

###### Races
- All PCs are human


